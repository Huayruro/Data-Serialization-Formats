#!/usr/bin/env python3
import json


#Deserializes JSON from a file into basic Python objects
with open('people.json', 'r') as people_json:
  people = json.load(people_json)
print(people)
